// animalController.js

const Animal = require('../animal/Animal.model');


export const test = (req, res)=>{
    console.log('test is running')
    return res.send({message: 'Test is running'})
}
 
// Función para registrar un animal
export const register = async(req, res)=>{
    try {
        // Capturar los datos del formulario (body)
        const data = req.body;
        console.log(data);
        
        // Crear una nueva instancia del modelo Animal
        const animal = new Animal(data);

        // Guardar el animal en la base de datos
        await animal.save();

        // Responder al cliente
        return res.send({ message: 'Animal registered successfully', animal });
    } catch (err) {
        console.error(err);
        return res.status(500).send({ message: 'Error registering animal', error: err });
    }
};



// Otras funciones como obtener un animal por ID, actualizar un animal, eliminar un animal, etc., se pueden implementar de manera similar

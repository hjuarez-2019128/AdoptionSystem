// animalRoutes.js

const express = require('express');

const MiAnimal = express.Router();
import {register, test} from './Animal.Controller';

MiAnimal.get('/testPet', test)
// Ruta para registrar un animal
MiAnimal.post('/registerPet', register)

// Ruta para obtener todos los animales
MiAnimal.get('/')

// Otras rutas se pueden definir de manera similar


export default MiAnimal

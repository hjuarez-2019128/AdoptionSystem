import mongoose from "mongoose"

const AnimalSchema = mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    race: {
        type: String,
        required: true
    },
    Domestic: {
        type: String,
        required: true
    },

    Wild: {
        type: String,
        required: true
    },

    nickname:{
        type: String,
        required: true
    },

    
})

//pre mongoose
                            //pluralizar
export default mongoose.model('Animal', AnimalSchema)